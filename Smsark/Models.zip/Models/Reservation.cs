﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Smsark.Models
{
    public class Reservation
    {
        [key]
        public int ReservationId { get; set; }
        public DateTime Date { get; set; }
        [ForeignKey("CustomerEmail")]
        public string CustomerEmail { get; set; }
        public Customer Customer { get; set; }
        public ICollection<ReservationItem>? reservationItems { get; set; }
        
    }
}
