﻿using Microsoft.EntityFrameworkCore;


namespace Smsark.Models
{
    public class SmsarkDb : DbContext
    {

        public SmsarkDb(DbContextOptions<SmsarkDb> options) : base(options)
        {

        }
        public DbSet<Apartment> apartments { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<Customer> customers { get; set; }
        public DbSet<Owner> owners { get; set; }
        public DbSet<Reservation> reservations { get; set; }
        public DbSet<ReservationItem> reservationItems { get; set; }
        public DbSet<Bed> Beds { get; set; }
        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<Reservation>()
        //       .HasOne(e => e.apartmentItem)
        //       .WithOne(e => e.reservation)
        //        .HasForeignKey<Room>(e => e.RoomId);
        //   }
        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {

            optionBuilder.UseSqlServer(@"
                           Server=DESKTOP-UVAA6CQ\SQL2022;
                           Database=Smsark;
                           Trusted_Connection=True;
                           TrustServerCertificate=True;");

        }
    }
    }

