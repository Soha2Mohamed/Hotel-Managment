﻿namespace Smsark.Models
{
    internal class keyAttribute : Attribute
    {
    }
}